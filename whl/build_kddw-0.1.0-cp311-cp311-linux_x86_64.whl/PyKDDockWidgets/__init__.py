# This file is part of KDDockWidgets.
#
# SPDX-FileCopyrightText: 2020 Klarälvdalens Datakonsult AB, a KDAB Group company <info@kdab.com>
# Author: Renato Araujo Oliveira Filho <renato.araujo@kdab.com>
#
# SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only
#
# Contact KDAB at <info@kdab.com> for commercial licensing options.
#

import sys
import os

__all__ = ['KDDockWidgets']

def setupLibraryPath():
    if sys.platform != 'win32':
        return

    if "6" == "6":
        from shiboken6 import Shiboken
    else:
        from shiboken6 import shiboken6 as Shiboken

    from PySide6 import QtCore
    extra_dll_dirs = [ os.path.abspath(os.path.dirname(Shiboken.__file__)),
                       os.path.abspath(os.path.dirname(QtCore.__file__)),
                       os.path.abspath(os.path.dirname(__file__)) ]

    if sys.version_info[0] == 3 and sys.version_info[1] >= 8:
        for dll_dir in extra_dll_dirs:
            os.add_dll_directory(dll_dir)

    for dll_dir in extra_dll_dirs:
        os.environ['PATH'] = os.fspath(dll_dir) + os.pathsep + os.environ['PATH']

# Preload PySide libraries to avoid missing libraries while loading KDDockWidgets
try:
    from PySide6 import QtCore
    # Create a alias for PySide module so we can use a single import in source files
    import PySide6
    sys.modules["PySide"] = PySide6
except Exception:
    print("Failed to load PySide")
    raise

setupLibraryPath()
